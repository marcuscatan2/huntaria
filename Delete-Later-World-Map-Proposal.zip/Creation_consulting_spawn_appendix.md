# Creation consulting — exact spawn appendix

Design proposal v0.1. All counts are concurrent available + reserved slots per active map layer, not per battle. Levels 1–60 are a deliberate rebalance. Six preview bosses require production approval and are not wild collectibles.

## ML01 · Hearthmeadow (Mosslight)
**Ordinary band:** 1–6. **Authored slots:** 156. **Connected to:** H_ML; ML02; ML05; WB01.
**Terrain:** Common meadow, shallow brook and old boundary stones
**Hunting identity:** Apprentice solo encounters; first frontline and damage companions
**Warning:** No roaming aggro on the arrival lawn; northern root arch visibly changes scale
**Return reason:** Train newly acquired companions, meet friends and pursue Seedskit clues

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Brimble | Fire | Dominant | 60 | 1–3 | Passive | Sun-warmed grass along the south lane |
| Bloomslime | Earth | Resident | 40 | 2–4 | Passive | Flower beds beside the brook |
| Rattlebit | Earth | Resident | 30 | 3–5 | Defensive | Rounded memorial stones, not the arrival lawn |
| Tideotter | Water | Resident | 25 | 4–6 | Passive | Shallow stream banks |
| Seedskit | Earth | Elusive | 1 | 5–6 | Skittish | Three seedpod hollows; only one occupied at once |

## ML02 · Acorn Commons (Mosslight)
**Ordinary band:** 5–12. **Authored slots:** 137. **Connected to:** H_ML; ML01; ML03; ML04; AH01.
**Terrain:** Oak commons with acorn beds and a fenced market road
**Hunting identity:** Durable melee populations; learn visible territorial groups
**Warning:** The Old Tuskettle leaves deep prints and stays inside its marked grove
**Return reason:** Reliable Earth tanks; early defense-team testing

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Tuskettle | Earth | Dominant | 50 | 6–9 | Defensive | Oak commons with acorn beds and a fenced market road |
| Pebblepup | Earth | Resident | 35 | 6–10 | Pack | Oak commons with acorn beds and a fenced market road |
| Cloverguard | Earth | Resident | 24 | 7–11 | Territorial | Oak commons with acorn beds and a fenced market road |
| Mossling | Earth | Resident | 24 | 5–8 | Passive | Oak commons with acorn beds and a fenced market road |
| Dewloop | Water | Rare | 3 | 8–10 | Passive | Dew pools around living roots |
| Tuskettle α | Earth | Miniboss | 1 | 18–18 | Territorial | Old Acorn Court, off the signed through-road |

## ML03 · Lantern Canopy (Mosslight)
**Ordinary band:** 10–18. **Authored slots:** 146. **Connected to:** ML02; ML04; ML05; MW01.
**Terrain:** Layered canopy paths, nectar flowers and raised wind bridges
**Hunting identity:** Support-versus-pressure decisions; ranged and tempo alternatives
**Warning:** Birdsong falls silent at the Ferncoil thickets; ambushers never spawn on bridges
**Return reason:** Honeylark, Grinroot and Glowcap utility; forest observation contracts

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Honeylark | Wind | Dominant | 55 | 10–14 | Passive | Layered canopy paths, nectar flowers and raised wind bridges |
| Grinroot | Earth | Resident | 30 | 12–16 | Defensive | Layered canopy paths, nectar flowers and raised wind bridges |
| Glowcap | Earth | Resident | 24 | 12–18 | Passive | Layered canopy paths, nectar flowers and raised wind bridges |
| Ferncoil | Earth | Resident | 18 | 14–18 | Ambush | Layered canopy paths, nectar flowers and raised wind bridges |
| Snipstream | Wind | Rare | 3 | 14–16 | Skittish | Layered canopy paths, nectar flowers and raised wind bridges |
| Mossling | Earth | Resident | 16 | 10–13 | Defensive | Layered canopy paths, nectar flowers and raised wind bridges |

## ML04 · Briarroot Hollows (Mosslight)
**Ordinary band:** 18–28. **Authored slots:** 126. **Connected to:** ML02; ML03; ML05; WS03.
**Terrain:** Root burrows, tangled clearings and broad-leaf ambush nests
**Hunting identity:** Readable ambush packs; choose robust companions and coherent priorities
**Warning:** Cut leaf husks and folded mantis silhouettes mark dangerous nests
**Return reason:** Leafmantis hunt and mixed-element team testing

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Ferncoil | Earth | Dominant | 50 | 18–24 | Ambush | Root burrows, tangled clearings and broad-leaf ambush nests |
| Grinroot | Earth | Resident | 30 | 19–24 | Pack | Root burrows, tangled clearings and broad-leaf ambush nests |
| Cloverguard | Earth | Resident | 24 | 20–26 | Territorial | Root burrows, tangled clearings and broad-leaf ambush nests |
| Glowcap | Earth | Resident | 16 | 21–25 | Passive | Root burrows, tangled clearings and broad-leaf ambush nests |
| Leafmantis α | Wind | Miniboss | 3 | 26–28 | Ambush | Three separate leaf-blade nests with approach warnings |
| Dewloop | Water | Rare | 3 | 20–22 | Passive | Root burrows, tangled clearings and broad-leaf ambush nests |

## ML05 · Elderwood Scar (Mosslight)
**Ordinary band:** 42–50. **Authored slots:** 139. **Connected to:** ML03; ML04; ML06; ML01; MW05.
**Terrain:** Huge petrified roots around a sunken forest wound
**Hunting identity:** Endgame forest formations, not a higher-level version of the starter lawn
**Warning:** Two safe overlooks, snapped colossal roots and a persistent skull-band notice
**Return reason:** Endgame woodland research and approach to Elderroot

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Cloverguard | Earth | Dominant | 50 | 42–46 | Territorial | Huge petrified roots around a sunken forest wound |
| Tuskettle | Earth | Resident | 30 | 44–48 | Pack | Huge petrified roots around a sunken forest wound |
| Glowcap | Earth | Resident | 24 | 43–46 | Passive | Huge petrified roots around a sunken forest wound |
| Ferncoil | Earth | Resident | 22 | 46–50 | Ambush | Huge petrified roots around a sunken forest wound |
| Honeylark | Wind | Resident | 12 | 42–44 | Passive | Huge petrified roots around a sunken forest wound |
| Cloverguard α | Earth | Miniboss | 1 | 54–54 | Territorial | Old guardian circle beneath the giant root arch |

## ML06 · Heartroot Sanctum (Mosslight)
**Ordinary band:** 56–56. **Authored slots:** 1. **Connected to:** ML05.
**Terrain:** Hollow guardian tree reached from the Scar
**Hunting identity:** Entrenched-guardian boss; pressure must resolve before Overcharge
**Warning:** Boss preview and deliberate entry; no accidental boss pulls
**Return reason:** Mastery challenge; source preview requires explicit production conversion

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Elderroot | Earth | Boss | 1 | 56–56 | Challenge | Hollow guardian tree reached from the Scar |

## WB01 · Reedbank Road (Willowbrook)
**Ordinary band:** 4–10. **Authored slots:** 163. **Connected to:** H_WB; WB02; WB05; ML01.
**Terrain:** Raised footpath through shallow freshwater reeds
**Hunting identity:** Accessible support, mobile Water damage and Wind companions
**Warning:** Road is clear; wetland silhouettes and sounds precede territorial pools
**Return reason:** Early support access without rare-species dependence

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Brooktoad | Water | Dominant | 50 | 5–8 | Passive | Raised footpath through shallow freshwater reeds |
| Lumimoth | Wind | Resident | 40 | 4–8 | Passive | Raised footpath through shallow freshwater reeds |
| Ironback | Earth | Resident | 25 | 6–10 | Defensive | Raised footpath through shallow freshwater reeds |
| Shellsnail | Water | Resident | 25 | 5–9 | Defensive | Raised footpath through shallow freshwater reeds |
| Keepsake | Water | Rare | 3 | 8–10 | Passive | Streamside remembrance stones |
| Tideotter | Water | Resident | 20 | 5–8 | Passive | Downstream continuation of the Mosslight stream |

## WB02 · Millrace Pools (Willowbrook)
**Ordinary band:** 10–18. **Authored slots:** 154. **Connected to:** H_WB; WB01; WB03; WB04; AH01.
**Terrain:** Watermill channels, stone weirs and turtle sandbanks
**Hunting identity:** Directional guards and charging foes; prepare formation before engagement
**Warning:** Old Ironback occupies a side sandbank rather than the bridge
**Return reason:** Tank alternatives, burst support and beginner pack practice

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Pluvault | Water | Dominant | 50 | 10–14 | Territorial | Watermill channels, stone weirs and turtle sandbanks |
| Snapglass | Water | Resident | 35 | 12–16 | Predator | Watermill channels, stone weirs and turtle sandbanks |
| Shellsnail | Water | Resident | 25 | 10–14 | Defensive | Watermill channels, stone weirs and turtle sandbanks |
| Driftjelly | Water | Resident | 20 | 12–18 | Defensive | Watermill channels, stone weirs and turtle sandbanks |
| Burrowlug | Earth | Rare | 3 | 14–18 | Territorial | Soft riverbank burrows |
| Ironback | Earth | Resident | 20 | 10–16 | Defensive | Watermill channels, stone weirs and turtle sandbanks |
| Ironback α | Earth | Miniboss | 1 | 24–24 | Territorial | Old turtle sandbank; never the mill bridge |

## WB03 · Lotus Fen (Willowbrook)
**Ordinary band:** 18–28. **Authored slots:** 146. **Connected to:** WB02; WB04; WB05.
**Terrain:** Open lotus water, flooded meadows and remnant stepping stones
**Hunting identity:** Sustain/control enemies; avoid building a team that only heals
**Warning:** Slow ribbons in water and cleared stepping-stone refuges
**Return reason:** Lotusmanta and Lilydeer research; diversified support teams

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Driftjelly | Water | Dominant | 50 | 18–24 | Predator | Open lotus water, flooded meadows and remnant stepping stones |
| Reefvault | Water | Resident | 30 | 20–26 | Predator | Open lotus water, flooded meadows and remnant stepping stones |
| Rillblade | Water | Resident | 25 | 20–26 | Pack | Open lotus water, flooded meadows and remnant stepping stones |
| Brooktoad | Water | Resident | 20 | 18–22 | Passive | Open lotus water, flooded meadows and remnant stepping stones |
| Lotusmanta | Water | Rare | 3 | 22–26 | Passive | Open lotus water, flooded meadows and remnant stepping stones |
| Lilydeer | Earth | Rare | 3 | 24–28 | Skittish | Open lotus water, flooded meadows and remnant stepping stones |
| Mistmelt | Water | Resident | 15 | 24–28 | Territorial | Open lotus water, flooded meadows and remnant stepping stones |

## WB04 · Sunken Causeway (Willowbrook)
**Ordinary band:** 28–38. **Authored slots:** 136. **Connected to:** WB02; WB03; WB05; WB06.
**Terrain:** Broken causeways, shell bars and a drowned shrine
**Hunting identity:** Short mobile attackers with recovery backlines
**Warning:** Visible dry platforms; no water damage on mere map entry
**Return reason:** Water skirmish practice and Tidecrown approach

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Rillblade | Water | Dominant | 55 | 28–34 | Pack | Broken causeways, shell bars and a drowned shrine |
| Veilheron | Wind | Resident | 30 | 30–36 | Predator | Broken causeways, shell bars and a drowned shrine |
| Mistmelt | Water | Resident | 25 | 30–38 | Territorial | Broken causeways, shell bars and a drowned shrine |
| Reefvault | Water | Resident | 20 | 28–34 | Predator | Broken causeways, shell bars and a drowned shrine |
| Keepsake | Water | Rare | 3 | 30–34 | Passive | Broken causeways, shell bars and a drowned shrine |
| Lotusmanta | Water | Rare | 3 | 32–36 | Passive | Broken causeways, shell bars and a drowned shrine |

## WB05 · Mourning Weir (Willowbrook)
**Ordinary band:** 44–52. **Authored slots:** 112. **Connected to:** WB03; WB04; WB06; WB01; MW04 [G01].
**Terrain:** Misty memorial channels beneath the old flood wall
**Hunting identity:** High-pressure ambush and protective spirits
**Warning:** Wind chimes reveal the Silkstep patrol; spawn exclusion at both exits
**Return reason:** Silkstep research; late-game wetland route to Moonwell

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Mistmelt | Water | Dominant | 50 | 44–50 | Territorial | Misty memorial channels beneath the old flood wall |
| Pluvault | Water | Resident | 30 | 44–48 | Territorial | Misty memorial channels beneath the old flood wall |
| Veilheron | Wind | Resident | 25 | 46–52 | Predator | Misty memorial channels beneath the old flood wall |
| Keepsake | Water | Rare | 3 | 44–48 | Passive | Misty memorial channels beneath the old flood wall |
| Lilydeer | Earth | Rare | 3 | 46–50 | Skittish | Misty memorial channels beneath the old flood wall |
| Silkstep α | Earth | Miniboss | 1 | 54–54 | Ambush | Memorial floodgate circuit; chimes announce patrol |

## WB06 · Crownwater Shrine (Willowbrook)
**Ordinary band:** 40–40. **Authored slots:** 1. **Connected to:** WB05; WB04.
**Terrain:** Circular shell sanctuary beyond the Causeway
**Hunting identity:** Defensive-zone boss
**Warning:** Intentional entry with a saved challenge state
**Return reason:** Proposed first-clear Tidecrown flag opens an optional drowned shortcut

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Tidecrown | Water | Boss | 1 | 40–40 | Challenge | Circular shell sanctuary beyond the Causeway |

## AH01 · Saffron Verge (Amber Hollow)
**Ordinary band:** 8–16. **Authored slots:** 153. **Connected to:** H_AH; AH02; AH05; ML02; WB02.
**Terrain:** Dry trade verge, warm stone fences and wind-bent flowers
**Hunting identity:** Early Fire/Wind alternatives without visiting the caldera
**Warning:** Long sightlines; Ashskate paths are confined to ash patches
**Return reason:** A second early-game route and accessible ranged attackers

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Amberkite | Wind | Dominant | 50 | 8–13 | Defensive | Dry trade verge, warm stone fences and wind-bent flowers |
| Bellowsnout | Fire | Resident | 35 | 10–14 | Defensive | Dry trade verge, warm stone fences and wind-bent flowers |
| Sunscarab | Fire | Resident | 25 | 10–15 | Territorial | Dry trade verge, warm stone fences and wind-bent flowers |
| Saffrune | Wind | Resident | 20 | 11–16 | Passive | Dry trade verge, warm stone fences and wind-bent flowers |
| Ashskate | Fire | Rare | 3 | 14–16 | Skittish | Dry trade verge, warm stone fences and wind-bent flowers |
| Brimble | Fire | Resident | 20 | 8–12 | Defensive | Warm trade-road boundary with Mosslight |

## AH02 · Resinwood Edge (Amber Hollow)
**Ordinary band:** 16–26. **Authored slots:** 126. **Connected to:** H_AH; AH01; AH03; AH04.
**Terrain:** Sticky amber groves, hollow seedpods and old insect trails
**Hunting identity:** Ambush bruisers backed by protective insects
**Warning:** Thornmaw jaws remain visible as environmental silhouettes
**Return reason:** Protective Fire companions and close-range composition tests

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Bellowsnout | Fire | Dominant | 50 | 16–21 | Pack | Sticky amber groves, hollow seedpods and old insect trails |
| Sunscarab | Fire | Resident | 30 | 17–22 | Territorial | Sticky amber groves, hollow seedpods and old insect trails |
| Amberkite | Wind | Resident | 25 | 18–23 | Predator | Sticky amber groves, hollow seedpods and old insect trails |
| Cindertroop | Fire | Rare | 3 | 20–24 | Pack | One collective actor per occupied ant procession |
| Thornmaw α | Earth | Miniboss | 3 | 24–26 | Ambush | Three giant hinged seedpods, each separated from the road |
| Saffrune | Wind | Resident | 15 | 18–22 | Passive | Sticky amber groves, hollow seedpods and old insect trails |

## AH03 · Old Kilnroad (Amber Hollow)
**Ordinary band:** 24–34. **Authored slots:** 155. **Connected to:** AH02; AH04; AH05; AR01.
**Terrain:** Abandoned brick kilns, cooling furnaces and caravan yards
**Hunting identity:** Pressure brawlers and ranged disruption
**Warning:** Living coal gathers inside kiln courtyards, away from the road
**Return reason:** Fire pressure builds, construct research and an Ashen foothill connection

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Cinderknuckle | Fire | Dominant | 50 | 24–30 | Pack | Abandoned brick kilns, cooling furnaces and caravan yards |
| Puffiend | Fire | Resident | 30 | 26–32 | Predator | Abandoned brick kilns, cooling furnaces and caravan yards |
| Resinrook | Earth | Resident | 25 | 26–34 | Territorial | Abandoned brick kilns, cooling furnaces and caravan yards |
| Wickeep | Fire | Resident | 20 | 24–28 | Passive | Abandoned brick kilns, cooling furnaces and caravan yards |
| Gonglet | Earth | Rare | 3 | 28–32 | Territorial | Abandoned brick kilns, cooling furnaces and caravan yards |
| Coalgrub | Fire | Resident | 12 | 26–30 | Defensive | Imported charcoal heaps along the Ashen trade road |
| Sunscarab | Fire | Resident | 15 | 25–30 | Territorial | Abandoned brick kilns, cooling furnaces and caravan yards |

## AH04 · Memorial Arcade (Amber Hollow)
**Ordinary band:** 30–40. **Authored slots:** 124. **Connected to:** AH02; AH03; AH05; AH06.
**Terrain:** Candle-lined colonnades, keepsake stalls and old ceremonial halls
**Hunting identity:** Haunted guards, protective souls and one rare doll
**Warning:** Warm memorial light communicates remembrance, not a new evil element
**Return reason:** Pinstitch and Marigloom; attrition and recovery team experiments

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Casketot | Earth | Dominant | 50 | 30–36 | Defensive | Candle-lined colonnades, keepsake stalls and old ceremonial halls |
| Wickeep | Fire | Resident | 30 | 30–34 | Passive | Candle-lined colonnades, keepsake stalls and old ceremonial halls |
| Ribwhirl | Earth | Resident | 25 | 32–38 | Pack | Candle-lined colonnades, keepsake stalls and old ceremonial halls |
| Marigloom | Earth | Rare | 3 | 32–36 | Passive | Candle-lined colonnades, keepsake stalls and old ceremonial halls |
| Pinstitch | Earth | Elusive | 1 | 36–40 | Skittish | One occupied rag-doll stall among five memorial alcoves |
| Gonglet | Earth | Rare | 3 | 32–36 | Territorial | Candle-lined colonnades, keepsake stalls and old ceremonial halls |
| Puffiend | Fire | Resident | 12 | 34–38 | Defensive | Candle-lined colonnades, keepsake stalls and old ceremonial halls |

## AH05 · Amber Fault (Amber Hollow)
**Ordinary band:** 46–56. **Authored slots:** 139. **Connected to:** AH03; AH04; AH06; AH01; AR04 [G02].
**Terrain:** Excavated amber canyon with disconnected colossal frames
**Hunting identity:** Heavy guards; offense allocation matters more than sustain stacking
**Warning:** Exposed giant cores and a wide warning terrace precede combat
**Return reason:** Endgame Earth teams and the optional kiln tunnel

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Resinrook | Earth | Dominant | 50 | 46–52 | Territorial | Excavated amber canyon with disconnected colossal frames |
| Ribwhirl | Earth | Resident | 35 | 48–54 | Pack | Excavated amber canyon with disconnected colossal frames |
| Cinderknuckle | Fire | Resident | 30 | 50–56 | Pack | Excavated amber canyon with disconnected colossal frames |
| Saffrune | Wind | Resident | 20 | 46–50 | Passive | Excavated amber canyon with disconnected colossal frames |
| Thornmaw | Earth | Rare | 3 | 50–54 | Ambush | Excavated amber canyon with disconnected colossal frames |
| Resinrook α | Earth | Miniboss | 1 | 58–58 | Territorial | Colossal frame excavation, separate from the vault entrance |

## AH06 · Colossus Vault (Amber Hollow)
**Ordinary band:** 48–48. **Authored slots:** 1. **Connected to:** AH05; AH04.
**Terrain:** Amber engine hall under the Fault
**Hunting identity:** Monumental-guard boss
**Warning:** Preview from a guarded balcony; explicit encounter acceptance
**Return reason:** Proposed first-clear Ambercolossus flag opens an optional tunnel

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Ambercolossus | Earth | Boss | 1 | 48–48 | Challenge | Amber engine hall under the Fault |

## MW01 · Moonshore Path (Moonwell)
**Ordinary band:** 12–20. **Authored slots:** 126. **Connected to:** H_MW; MW02; MW05; ML03.
**Terrain:** Shallow crater-lake shore and pale gravel beaches
**Hunting identity:** Precision Water damage and restorative alternatives
**Warning:** Shardclaw scratches and conspicuous patrols; safe shore bypass
**Return reason:** First Moonwell visit well before the high-level caves

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Starfrog | Water | Dominant | 50 | 12–17 | Defensive | Shallow crater-lake shore and pale gravel beaches |
| Cairnclamp | Earth | Resident | 30 | 14–20 | Territorial | Shallow crater-lake shore and pale gravel beaches |
| Pillowisp | Water | Rare | 3 | 14–18 | Passive | Shallow crater-lake shore and pale gravel beaches |
| Dreamtapir | Water | Resident | 25 | 13–18 | Passive | Shallow crater-lake shore and pale gravel beaches |
| Shardclaw α | Water | Miniboss | 3 | 22–24 | Predator | Three gravel inlets with a continuous safe shoreline bypass |
| Lumimoth | Wind | Resident | 15 | 12–16 | Passive | Connected wet woodland from the southern lake |

## MW02 · Hushgrove (Moonwell)
**Ordinary band:** 20–30. **Authored slots:** 148. **Connected to:** H_MW; MW01; MW03; MW04; WS01.
**Terrain:** Quiet woods with feather masks and soft fungal lights
**Hunting identity:** Ranged disruption and sustain; evaluate target priorities
**Warning:** Mask shapes and owl calls identify pressure groups
**Return reason:** Midgame ranged/support teams and a route into Windstep

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Hushowl | Wind | Dominant | 50 | 20–26 | Predator | Quiet woods with feather masks and soft fungal lights |
| Lunaskein | Wind | Resident | 30 | 22–28 | Defensive | Quiet woods with feather masks and soft fungal lights |
| Dreamtapir | Water | Resident | 25 | 20–24 | Passive | Quiet woods with feather masks and soft fungal lights |
| Veilora | Wind | Resident | 20 | 22–28 | Territorial | Quiet woods with feather masks and soft fungal lights |
| Mirrormantis | Wind | Resident | 20 | 24–30 | Ambush | Quiet woods with feather masks and soft fungal lights |
| Pillowisp | Water | Rare | 3 | 22–26 | Passive | Quiet woods with feather masks and soft fungal lights |

## MW03 · Mirrorwater Grotto (Moonwell)
**Ordinary band:** 30–40. **Authored slots:** 148. **Connected to:** MW02; MW04; MW05.
**Terrain:** Reflective pools, clear crystal walls and silk bridges
**Hunting identity:** Water burst with guardians; defined packs rather than random stat walls
**Warning:** False reflections stay visible before entry; no off-screen attack starts
**Return reason:** Hexurchin, Pearlweaver and precision-team research

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Pearlweaver | Water | Dominant | 50 | 30–36 | Predator | Reflective pools, clear crystal walls and silk bridges |
| Starfrog | Water | Resident | 30 | 30–34 | Pack | Reflective pools, clear crystal walls and silk bridges |
| Cairnclamp | Earth | Resident | 25 | 32–38 | Territorial | Reflective pools, clear crystal walls and silk bridges |
| Inksprite | Water | Resident | 25 | 34–40 | Predator | Reflective pools, clear crystal walls and silk bridges |
| Hexurchin | Water | Rare | 3 | 34–38 | Territorial | Reflective pools, clear crystal walls and silk bridges |
| Lunaskein | Wind | Resident | 15 | 32–36 | Defensive | Reflective pools, clear crystal walls and silk bridges |

## MW04 · Bellshadow Cloister (Moonwell)
**Ordinary band:** 40–50. **Authored slots:** 129. **Connected to:** MW02; MW03; MW05; WB05 [G01].
**Terrain:** Moonlit memorial terraces with audible bells and strong cast shadows
**Hunting identity:** Protective spirits and disruption; cleanse/priority decisions
**Warning:** Echochime shadows remain readable at mobile camera scale
**Return reason:** Echochime and Cairnkin; shortcut to Willowbrook

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Cairnkin | Earth | Dominant | 50 | 40–46 | Territorial | Moonlit memorial terraces with audible bells and strong cast shadows |
| Maskin | Earth | Resident | 30 | 42–48 | Defensive | One collective actor per carried mask |
| Veilora | Wind | Resident | 25 | 40–46 | Territorial | Moonlit memorial terraces with audible bells and strong cast shadows |
| Echochime | Wind | Rare | 3 | 44–48 | Passive | Shadow-readable bell courts, never cluttered dark ground |
| Mirrormantis | Wind | Resident | 20 | 44–50 | Ambush | Moonlit memorial terraces with audible bells and strong cast shadows |
| Mirrormantis α | Wind | Miniboss | 1 | 54–54 | Ambush | Single false-reflection courtyard |

## MW05 · Eclipse Basin (Moonwell)
**Ordinary band:** 50–58. **Authored slots:** 134. **Connected to:** MW03; MW04; MW06 [G03]; MW01; ML05.
**Terrain:** Black mirror water beneath a visible crescent web
**Hunting identity:** Mixed ranged pressure, guard structures and evasive quarry
**Warning:** Web horizon and dark water mark a hard escalation from Moonshore
**Return reason:** Inkmarten research and Moonweaver mastery

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Inksprite | Water | Dominant | 50 | 50–56 | Predator | Black mirror water beneath a visible crescent web |
| Pearlweaver | Water | Resident | 35 | 52–58 | Predator | Black mirror water beneath a visible crescent web |
| Lunaskein | Wind | Resident | 25 | 50–54 | Defensive | Black mirror water beneath a visible crescent web |
| Cairnkin | Earth | Resident | 20 | 52–56 | Territorial | Black mirror water beneath a visible crescent web |
| Hexurchin | Water | Rare | 3 | 54–58 | Territorial | Black mirror water beneath a visible crescent web |
| Inkmarten | Water | Elusive | 1 | 56–58 | Skittish | One ink-bank den occupied among five viable burrows |

## MW06 · Moonweaver Loom (Moonwell)
**Ordinary band:** 60–60. **Authored slots:** 1. **Connected to:** MW05 [G03].
**Terrain:** Silk span above a deep lunar pool
**Hunting identity:** Web-control boss
**Warning:** Three readable phases authored within the existing battle deadline
**Return reason:** Optional capstone behind any two of three guardian clears; not a gate to ordinary Moonwell

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Moonweaver | Water | Boss | 1 | 60–60 | Challenge | Silk span above a deep lunar pool |

## WS01 · Lowwind Pasture (Windstep)
**Ordinary band:** 14–24. **Authored slots:** 141. **Connected to:** H_WS; WS02; MW02.
**Terrain:** Broad upland meadows below sheltering stone ridges
**Hunting identity:** Low-altitude Wind creatures and durable grazing Earth companions
**Warning:** Sheltered path remains usable; aggressive creatures stay beyond windbreaks
**Return reason:** Windstep accessible before late game; new tempo/frontline choices

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Hopgrit | Wind | Dominant | 55 | 14–20 | Defensive | Broad upland meadows below sheltering stone ridges |
| Whistlepod | Wind | Resident | 35 | 14–18 | Passive | Broad upland meadows below sheltering stone ridges |
| Fluffyak | Earth | Resident | 25 | 18–24 | Territorial | Broad upland meadows below sheltering stone ridges |
| Cloudfin | Wind | Rare | 3 | 18–22 | Passive | Broad upland meadows below sheltering stone ridges |
| Honeylark | Wind | Resident | 20 | 14–18 | Passive | Nectar meadow adjoining Mosslight watershed |
| Tempestool | Wind | Rare | 3 | 20–24 | Defensive | Broad upland meadows below sheltering stone ridges |

## WS02 · Whistlegrass Steppe (Windstep)
**Ordinary band:** 24–34. **Authored slots:** 131. **Connected to:** H_WS; WS01; WS03; WS04.
**Terrain:** Tall whistling seedpods, open fields and rolling air currents
**Hunting identity:** Tempo and support populations with honest ranged pressure
**Warning:** Seedpod rhythm forecasts nearby creature groups
**Return reason:** Whistlepod and Cloudfin research; alternative midgame hunting

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Whistlepod | Wind | Dominant | 50 | 24–28 | Passive | Tall whistling seedpods, open fields and rolling air currents |
| Brontobug | Wind | Resident | 30 | 26–32 | Pack | Tall whistling seedpods, open fields and rolling air currents |
| Windlass | Wind | Resident | 25 | 28–34 | Territorial | Tall whistling seedpods, open fields and rolling air currents |
| Hopgrit | Wind | Resident | 20 | 24–30 | Defensive | Tall whistling seedpods, open fields and rolling air currents |
| Cloudfin | Wind | Rare | 3 | 26–30 | Passive | Tall whistling seedpods, open fields and rolling air currents |
| Squallcub | Wind | Rare | 3 | 28–32 | Defensive | Tall whistling seedpods, open fields and rolling air currents |

## WS03 · Razorwind Pass (Windstep)
**Ordinary band:** 34–44. **Authored slots:** 131. **Connected to:** WS02; WS04; WS05; ML04.
**Terrain:** Narrow cliffs connected by broad recovery terraces
**Hunting identity:** Fast melee packs with protective allies
**Warning:** Scraped rock and Brontobug drum beats warn before encounters
**Return reason:** Mid/high-game tempo-team training and a risky Mosslight shortcut

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Razorwing | Wind | Dominant | 50 | 34–40 | Predator | Narrow cliffs connected by broad recovery terraces |
| Cragbeak | Earth | Resident | 30 | 36–42 | Territorial | Narrow cliffs connected by broad recovery terraces |
| Windlass | Wind | Resident | 25 | 38–44 | Territorial | Narrow cliffs connected by broad recovery terraces |
| Fluffyak | Earth | Resident | 20 | 34–38 | Defensive | Narrow cliffs connected by broad recovery terraces |
| Squallcub | Wind | Rare | 3 | 38–42 | Predator | Narrow cliffs connected by broad recovery terraces |
| Brontobug α | Wind | Miniboss | 3 | 46–48 | Pack | Three separate drum pits on broad side terraces |

## WS04 · Skyglass Cliffs (Windstep)
**Ordinary band:** 44–54. **Authored slots:** 131. **Connected to:** WS02; WS03; WS05; AR04.
**Terrain:** Tall prismatic columns, suspended flower beds and open sky
**Hunting identity:** Aerial ranged pressure; robust frontline plus a decisive damage plan
**Warning:** Prismatic trails and hanging flowers display safe versus dangerous ledges
**Return reason:** Skycorolla and Prismspear; passage toward Ashen Reach

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Prismspear | Wind | Dominant | 50 | 44–50 | Predator | Tall prismatic columns, suspended flower beds and open sky |
| Razorwing | Wind | Resident | 30 | 46–52 | Predator | Tall prismatic columns, suspended flower beds and open sky |
| Cragbeak | Earth | Resident | 25 | 48–54 | Territorial | Tall prismatic columns, suspended flower beds and open sky |
| Kiteskulk | Wind | Rare | 3 | 48–52 | Ambush | Tall prismatic columns, suspended flower beds and open sky |
| Skycorolla | Wind | Rare | 3 | 50–54 | Skittish | Tall prismatic columns, suspended flower beds and open sky |
| Fluffyak | Earth | Resident | 20 | 44–48 | Defensive | Tall prismatic columns, suspended flower beds and open sky |

## WS05 · Stormcrown Ring (Windstep)
**Ordinary band:** 52–58. **Authored slots:** 108. **Connected to:** WS03; WS04; WS06.
**Terrain:** Circular storm ridge around an open-air ancient roost
**Hunting identity:** Wind control and protective skull guardians
**Warning:** Rib-shield silhouettes and a stationary storm boundary
**Return reason:** Hornvault and Velvimp research; Tempestrook challenge

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Windlass | Wind | Dominant | 50 | 52–56 | Territorial | Circular storm ridge around an open-air ancient roost |
| Prismspear | Wind | Resident | 30 | 54–58 | Predator | Circular storm ridge around an open-air ancient roost |
| Whistlepod | Wind | Resident | 20 | 52–54 | Passive | Circular storm ridge around an open-air ancient roost |
| Tempestool | Wind | Rare | 3 | 54–58 | Defensive | Circular storm ridge around an open-air ancient roost |
| Kiteskulk | Wind | Rare | 3 | 54–58 | Ambush | Circular storm ridge around an open-air ancient roost |
| Hornvault α | Wind | Miniboss | 1 | 60–60 | Territorial | Single rib-shield guardian circuit at the old roost |
| Velvimp | Wind | Elusive | 1 | 56–58 | Skittish | One occupied wind-fold hiding place among five ledges |

## WS06 · Tempest Roost (Windstep)
**Ordinary band:** 60–60. **Authored slots:** 1. **Connected to:** WS05.
**Terrain:** Great corvid roost reached from the storm ring
**Hunting identity:** Aerial boss damage under a finite battle clock
**Warning:** Boss remains visible from a noncombat refuge
**Return reason:** Optional high-level mastery without unlocking ordinary Windstep

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Tempestrook | Wind | Boss | 1 | 60–60 | Challenge | Great corvid roost reached from the storm ring |

## AR01 · Warmstone Foothills (Ashen Reach)
**Ordinary band:** 18–28. **Authored slots:** 148. **Connected to:** H_AR; AR02; AH03.
**Terrain:** Cooling lava terraces, low fumaroles and a maintained caravan track
**Hunting identity:** First volcanic creatures without a level-80 entry tax
**Warning:** Heat haze and stone warnings precede hostile shelves
**Return reason:** Fire/Earth pressure companions and a distinct midgame route

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Kilncoil | Fire | Dominant | 50 | 18–24 | Predator | Cooling lava terraces, low fumaroles and a maintained caravan track |
| Cairnox | Earth | Resident | 30 | 20–26 | Defensive | Cooling lava terraces, low fumaroles and a maintained caravan track |
| Crucibulk | Fire | Resident | 25 | 22–28 | Territorial | Cooling lava terraces, low fumaroles and a maintained caravan track |
| Slagbud | Earth | Resident | 25 | 18–22 | Passive | Cooling lava terraces, low fumaroles and a maintained caravan track |
| Ashskate | Fire | Rare | 3 | 20–24 | Skittish | Shared cooling-ash corridor from Amber Hollow |
| Bellowsnout | Fire | Resident | 15 | 18–22 | Defensive | Warm scrub above the Amber trade road |

## AR02 · Steamgarden (Ashen Reach)
**Ordinary band:** 28–38. **Authored slots:** 158. **Connected to:** H_AR; AR01; AR03; AR04.
**Terrain:** Warm clean springs and mineral gardens between dormant vents
**Hunting identity:** Water cleansing and sustain inside a Fire-dominant region
**Warning:** Gentle steam pools contrast with hostile vent mouths
**Return reason:** Steamaxolotl and Auroradrake are local inhabitants, not elemental mistakes

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Steamaxolotl | Water | Dominant | 50 | 28–34 | Passive | Warm clean springs and mineral gardens between dormant vents |
| Auroradrake | Water | Resident | 30 | 30–36 | Defensive | Warm clean springs and mineral gardens between dormant vents |
| Slagbud | Earth | Resident | 30 | 28–32 | Territorial | Warm clean springs and mineral gardens between dormant vents |
| Coalgrub | Fire | Resident | 25 | 32–38 | Pack | Warm clean springs and mineral gardens between dormant vents |
| Cinderwink | Fire | Resident | 20 | 30–34 | Passive | Warm clean springs and mineral gardens between dormant vents |
| Dewloop | Water | Rare | 3 | 30–34 | Passive | Condensation rings in clear spring overflow |

## AR03 · Cinderworks (Ashen Reach)
**Ordinary band:** 38–48. **Authored slots:** 158. **Connected to:** AR02; AR04; AR05.
**Terrain:** Living kiln corridors, charcoal deposits and broken heat exchangers
**Hunting identity:** Advancing brawlers and burst plants
**Warning:** Kiln hum and flower opening silhouettes identify pressure packs
**Return reason:** Offensive Fire teams and defensive support alternatives

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Pyreling | Fire | Dominant | 50 | 38–44 | Predator | Living kiln corridors, charcoal deposits and broken heat exchangers |
| Kilncoil | Fire | Resident | 35 | 40–46 | Pack | Living kiln corridors, charcoal deposits and broken heat exchangers |
| Coalgrub | Fire | Resident | 25 | 40–44 | Pack | Living kiln corridors, charcoal deposits and broken heat exchangers |
| Crucibulk | Fire | Resident | 25 | 42–48 | Territorial | Living kiln corridors, charcoal deposits and broken heat exchangers |
| Cinderwink | Fire | Resident | 20 | 38–42 | Passive | Living kiln corridors, charcoal deposits and broken heat exchangers |
| Emberorchid | Fire | Rare | 3 | 44–48 | Ambush | Predatory flowers beside nutrient-rich warm vents |

## AR04 · Obsidian Shelf (Ashen Reach)
**Ordinary band:** 48–56. **Authored slots:** 112. **Connected to:** AR02; AR03; AR05; WS04; AH05 [G02].
**Terrain:** Black-glass escarpment above quarry pits and lava tubes
**Hunting identity:** Ranged attrition with a rare space-holding quarry construct
**Warning:** Slagjaw's stone tracks never cross the town approach
**Return reason:** Slagjaw and Glassphoenix research; amber tunnel endpoint

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Ashbasilisk | Fire | Dominant | 50 | 48–54 | Predator | Black-glass escarpment above quarry pits and lava tubes |
| Cairnox | Earth | Resident | 30 | 48–52 | Pack | Black-glass escarpment above quarry pits and lava tubes |
| Slagbud | Earth | Resident | 25 | 48–52 | Territorial | Black-glass escarpment above quarry pits and lava tubes |
| Glassphoenix | Fire | Rare | 3 | 52–56 | Predator | Black-glass escarpment above quarry pits and lava tubes |
| Mournmantle | Fire | Rare | 3 | 50–54 | Passive | Black-glass escarpment above quarry pits and lava tubes |
| Slagjaw α | Earth | Miniboss | 1 | 58–58 | Territorial | Single quarry bowl with visible jaw tracks and two exits |

## AR05 · Crimson Caldera (Ashen Reach)
**Ordinary band:** 54–60. **Authored slots:** 132. **Connected to:** AR03; AR04; AR06.
**Terrain:** Lava-rim habitat islands with cooler walls and guarded approaches
**Hunting identity:** Armor-phase pressure and protective Fire support
**Warning:** Moltencoil rings and safe observation platforms telegraph escalation
**Return reason:** Endgame Fire teams and Cinderempress approach

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Moltencoil | Fire | Dominant | 50 | 54–58 | Predator | Lava-rim habitat islands with cooler walls and guarded approaches |
| Ashbasilisk | Fire | Resident | 30 | 54–58 | Predator | Lava-rim habitat islands with cooler walls and guarded approaches |
| Pyreling | Fire | Resident | 25 | 56–60 | Pack | Lava-rim habitat islands with cooler walls and guarded approaches |
| Cinderwink | Fire | Resident | 20 | 54–58 | Passive | Lava-rim habitat islands with cooler walls and guarded approaches |
| Glassphoenix | Fire | Rare | 3 | 56–60 | Predator | Lava-rim habitat islands with cooler walls and guarded approaches |
| Mournmantle | Fire | Rare | 3 | 56–60 | Passive | Lava-rim habitat islands with cooler walls and guarded approaches |
| Moltencoil α | Fire | Miniboss | 1 | 60–60 | Predator | Single royal slag-ring patrol on the inner rim |

## AR06 · Empress Furnace (Ashen Reach)
**Ordinary band:** 60–60. **Authored slots:** 1. **Connected to:** AR05.
**Terrain:** Royal salamander chamber at the caldera's heart
**Hunting identity:** Close-range pressure boss
**Warning:** Regal fan silhouette and explicit challenge start
**Return reason:** Optional capstone mastery; not a mandatory ending to the whole world

| Monster | Element | Tier | Slots | Level | Aggro | Microhabitat |
|---|---|---|---:|---|---|---|
| Cinderempress | Fire | Boss | 1 | 60–60 | Challenge | Royal salamander chamber at the caldera's heart |
